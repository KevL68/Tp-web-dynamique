from django.db import models

class Film(models.Model):
    titre = models.CharField(max_length=255)
    date_sortie = models.DateField()
    realisateur = models.CharField(max_length=255)
    categories = models.CharField(max_length=255)
