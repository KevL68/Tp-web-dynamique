from django.shortcuts import render, redirect
from .models import Film

def index(request):
    return render(request, 'film/index.html')

def ajouter_film(request):
    if request.method == 'POST':
        titre = request.POST['titre']
        date_sortie = request.POST['date_sortie']
        realisateur = request.POST['realisateur']
        categories = request.POST['categories']
        Film.objects.create(titre=titre, date_sortie=date_sortie, realisateur=realisateur, categories=categories)
        return redirect('liste_films')
    return render(request, 'film/ajouter_film.html')

def liste_films(request):
    films = Film.objects.all()
    return render(request, 'film/liste_films.html', {'films': films})

def categories_films(request):
    categories = ['Action', 'Comédie', 'Fantastique', 'Science Fiction', 'Horreur']
    if request.method == 'POST':
        categorie_selectionnee = request.POST['categorie']
        films = Film.objects.filter(categories=categorie_selectionnee)
        return render(request, 'film/categorie_films.html', {'films': films, 'categorie_selectionnee': categorie_selectionnee})
    return render(request, 'film/categories_films.html', {'categories': categories})
