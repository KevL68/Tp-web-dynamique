from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('ajouter-film/', views.ajouter_film, name='ajouter_film'),
    path('liste-films/', views.liste_films, name='liste_films'),
    path('categories-films/', views.categories_films, name='categories_films'),
]
